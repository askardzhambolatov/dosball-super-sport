# DOSBALL Roadmap

## Phase 1 — Digital foundation
- GitHub repository
- project website
- brand asset library
- multilingual content
- video game prototype
- federation member database

## Phase 2 — Member platform
- registration and authentication
- member profile
- subscriptions
- personal referral links
- reward dashboard
- club directory
- coach profiles

## Phase 3 — Physical clubs
- pilot clubs
- coach certification
- franchise package
- equipment standards
- local competitions

## Phase 4 — Professional competition
- Premier League
- High League
- Super National League
- national championships
- family competition format

## Phase 5 — International expansion
- international competition every two years
- new host countries
- federation partnerships
- education and government programs
- global sponsors and media
