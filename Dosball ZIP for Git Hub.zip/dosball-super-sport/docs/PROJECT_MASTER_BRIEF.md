# DOSBALL Project Master Brief

## Vision

DOSBALL Super Sport International is designed as a global sports ecosystem combining a new physical team sport with a digital video game, federation membership, clubs, coaches, leagues, international competitions, athlete career development, entrepreneurship and social responsibility.

## Core principle

**DOSBALL brings Sport, Society, State and Business together for the benefit of society.**

## Digital-first rollout

1. Launch the DOSBALL video game and digital membership experience.
2. Build federation registration and member profiles.
3. Launch local clubs, coaching programs and franchise operations.
4. Develop national leagues and championships.
5. Expand through international competitions and strategic partnerships.

## Main modules

- Sport
- Federation
- Video Game
- Clubs
- Coaches
- Franchise
- Premier / High / Super National Leagues
- Championships
- International Competitions
- Academy of Succession
- Member career progression
- Referral and ecosystem product promotion
- Rewards
- Merchandise
- Charity and social responsibility
- Government and education cooperation
- International expansion

## Product principle

The platform should be mobile-first, multilingual, simple for members to use, and transparent in all reward, payment and progression logic.

## Compliance principle

Financial, referral, franchise, charitable and inheritance mechanisms must be independently reviewed for compliance in every operating jurisdiction.
