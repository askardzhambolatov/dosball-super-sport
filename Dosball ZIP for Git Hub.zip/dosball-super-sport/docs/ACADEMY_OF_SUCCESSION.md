# Academy of Succession

The Academy of Succession is the DOSBALL career and leadership pathway.

## Career path

A member may progress from:

Club Player → Competitive Athlete → Champion → Mentor → Coach → Club Director → Regional Director → International Regional Director → Federation Leadership.

## Competitive recognition

Athletes who place 1st, 2nd or 3rd in recognized DOSBALL competitions can enter enhanced development pathways.

## Leadership development

The Academy can provide:

- coaching education
- club-management education
- federation administration
- event management
- youth mentoring
- sports entrepreneurship
- ethics and transparency training

## Champion opportunities

Top international champions may qualify for special franchise privileges or fee discounts under federation policy.

## Succession

The goal is to create continuity so successful athletes can remain part of DOSBALL after their competitive career and move into coaching, management and international leadership.
