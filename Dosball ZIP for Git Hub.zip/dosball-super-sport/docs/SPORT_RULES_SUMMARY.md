# DOSBALL Sport Rules — Summary

This document is a high-level project summary, not the final official rulebook.

## Playing format

- Basketball-sized court concept
- 6 players per team on court
- Up to 25 players in the roster concept
- Rolling substitutions
- One referee concept
- Three periods of 20 minutes clean time
- First period: sneakers
- Second period: roller skates
- Third period: sneakers

## Goals / rings

Each end of the court uses three vertical rings:
- one central vertical ring
- two side rings positioned next to the central ring and angled inward

## Ball and scoring

The DOSBALL ball is smaller than a standard handball concept and designed to be highly responsive.

Scoring concept:
- fist strike through a ring: 2 points
- hand throw through a ring: 1 point
- knee technique is part of the sport concept

## Overtime concept

Three players receive three attempts using different techniques.

## Official rules

The project references a full 27-rule system. The complete official rulebook should be maintained as a separate controlled document with version history.
