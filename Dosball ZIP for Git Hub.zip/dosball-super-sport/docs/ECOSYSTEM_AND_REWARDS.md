# Ecosystem and Rewards

## Member access

Eligible federation members can receive access to approved DOSBALL ecosystem products and programs.

## Video game

The video game is intended to be the first scalable global product and a digital entry point into the DOSBALL ecosystem.

## Referral link

Eligible members may receive a personal referral link for approved ecosystem products. Reward calculations should be visible inside the member dashboard.

Any referral system must be based on real products and services, not recruitment for its own sake, and must comply with consumer, tax, advertising and direct-selling laws in each country.

## Franchise referral

Where legally permitted, a federation-approved referral mechanism may reward a member for introducing a verified franchise buyer. Final percentages, duration and conditions must be defined in formal franchise agreements.

## Inheritance and continuity

The federation may create a succession mechanism for eligible member accounts so approved benefits can pass to lawful heirs or nominated successors. This requires country-specific legal, tax and estate-planning review.

## Transparency

Every member dashboard should show:

- active products
- subscription status
- approved referrals
- reward calculation
- payment history
- status and career progression
- federation notices
