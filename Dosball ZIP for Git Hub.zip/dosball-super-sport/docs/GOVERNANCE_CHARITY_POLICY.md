# Governance, Social Responsibility and Charity

## Transparency

DOSBALL should publish clear rules for membership, rewards, franchise relations, competitions and charitable projects.

## Voluntary charity

Charitable participation must be voluntary, transparent and separated from compulsory sport or membership payments unless local law and explicit program terms provide otherwise.

## Social priorities

Programs may support:

- athletes and their families
- children and orphans
- widows
- low-income families
- community sport development
- education and youth programs

## Education and government cooperation

DOSBALL can propose free cooperation programs to ministries, municipalities, schools, colleges and universities, including introductory rules, PE modules, extracurricular clubs and demonstration events.

## Anti-gambling policy

DOSBALL must never be connected to:

- sports betting
- wagering
- gambling
- lotteries
- gambling-style contests
- gambling-related commercial activity
