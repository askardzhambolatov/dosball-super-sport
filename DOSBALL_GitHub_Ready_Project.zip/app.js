const career = [
  ["01","Club Player","Learns DOSBALL rules, trains and joins club competitions."],
  ["02","Club Team Leader","Builds leadership, discipline and team responsibility."],
  ["03","Regional Athlete","Competes at district, city and regional levels."],
  ["04","League Athlete","Advances toward Premier, High or Super National League."],
  ["05","Champion / Medalist","1st–3rd place opens the Academy of Succession pathway."],
  ["06","Assistant Coach / Coach","Completes coaching, safety and athlete-development training."],
  ["07","Club Manager / Franchise Operator","Learns club economics, operations, ethics and community standards."],
  ["08","Area Club Director","Supports several clubs and certified local operations."],
  ["09","National Club Director","Coordinates club growth and quality at national level."],
  ["10","International Regional Director","Leads DOSBALL club development across an international region."],
  ["11","Federation Committee Leader","Contributes to sport, education, commercial or social programs."],
  ["12","Federation Council Candidate","May be nominated for Federation Council governance under Federation rules."]
];

const careerRu = [
  ["01","Игрок клуба","Изучает правила DOSBALL, тренируется и участвует в клубных соревнованиях."],
  ["02","Лидер клубной команды","Развивает дисциплину, лидерство и ответственность за команду."],
  ["03","Региональный спортсмен","Участвует в районных, городских и региональных турнирах."],
  ["04","Игрок лиги","Продвигается в Premier, High или Super National League."],
  ["05","Чемпион / призёр","1–3 место открывает путь в Академию преемственности."],
  ["06","Ассистент тренера / тренер","Проходит подготовку по тренерской работе, безопасности и развитию спортсменов."],
  ["07","Менеджер клуба / оператор франшизы","Осваивает экономику клуба, управление, этику и общественные стандарты."],
  ["08","Территориальный директор клубов","Курирует несколько клубов и сертифицированные местные операции."],
  ["09","Национальный директор клубов","Координирует развитие и качество сети клубов в стране."],
  ["10","Международный региональный директор","Руководит развитием клубов DOSBALL в международном регионе."],
  ["11","Руководитель комитета Федерации","Участвует в спортивных, образовательных, коммерческих или социальных программах."],
  ["12","Кандидат в Совет Федерации","Может быть номинирован в Совет Федерации согласно правилам Федерации."]
];

const t = {
en:{
navSport:"Sport",navAcademy:"Academy",navCareer:"Career",navEcosystem:"Ecosystem",navCharity:"Charity",navFederation:"Federation",
eyebrow:"NEW WORLD SPORT • GLOBAL ECOSYSTEM",heroTitle:"From club player to international leadership.",heroLead:"DOSBALL unites sport, society, state and business for the benefit of society — through clubs, digital products, education, transparent rewards and voluntary charity.",joinBtn:"Join the Federation",careerBtn:"See Career Path",ageRange:"member age range",periods:"clean-time periods",rules:"core sport rules",leagues:"professional leagues",heroCard:"Basketball + Volleyball + Handball + Rugby + Football — reimagined as a new super sport.",
sportEyebrow:"THE SPORT",sportTitle:"Fast, physical, spectacular.",sport1t:"Three periods",sport1:"1st: sneakers • 2nd: roller skates • 3rd: sneakers. Each period is 20 minutes of clean time.",sport2t:"Six on court",sport2:"Six players compete at once, with hockey-style substitutions and a 25-player roster.",sport3t:"Unique scoring",sport3:"Fist strike through a ring: 2 points. Hand throw: 1 point. Knee strikes are part of the game.",
academyEyebrow:"ACADEMY OF SUCCESSION",academyTitle:"Champions become mentors, managers and future leaders.",academyText:"The Academy of Succession converts sporting achievement into education, professional development and long-term leadership inside the DOSBALL Federation.",
a1t:"Club Athlete",a1:"Training, rules, teamwork, digital profile and first competitions.",a2t:"Regional Competitor",a2:"Participation in local and regional championships.",a3t:"League Athlete",a3:"Progression into Premier, High and Super National League pathways.",a4t:"Champion 1st–3rd",a4:"Medalists enter the Academy of Succession and leadership track.",a5t:"Coach / Club Manager",a5:"Training in coaching, club operations, ethics, finance and community work.",a6t:"International Regional Director",a6:"Leadership of DOSBALL clubs across a region or country, based on results and certification.",a7t:"Federation Council Member",a7:"Top leaders may be nominated to Federation governance in accordance with Federation rules.",
careerEyebrow:"CAREER GROWTH",careerTitle:"Every player has a visible path forward.",careerRuleT:"Merit first.",careerRule:"Promotion is based on sporting results, education, ethics, leadership, certified experience and Federation requirements — not on recruitment alone.",
ecoEyebrow:"DOSBALL ECOSYSTEM",ecoTitle:"One membership. Sport, digital products and entrepreneurship.",gameTitle:"DOSBALL Video Game Access",gameText:"A monthly purchase activates personal access for one month and Federation ecosystem benefits attached to the active account.",refTitle:"Personal Referral Link",refText:"Any eligible Federation member aged 10–70 may receive a personal referral link while the monthly video-game purchase is active.",generateBtn:"Generate demo link",copyBtn:"Copy",rightsTitle:"Use, Gift or Resell for 1 Month",rightsText:"The active monthly digital entitlement may be used personally, gifted, or offered for resale for its one-month term, subject to Federation terms and applicable law.",minorT:"Members under 18:",minorText:"commercial activity, payments and contracts must be handled with parent/guardian consent and in accordance with local law.",
heritageEyebrow:"CONTINUITY & INHERITANCE",heritageTitle:"A member’s contribution can continue for the family.",heritageText:"Where a member has created a recognized DOSBALL team, club network or qualifying reward account, Federation rules may provide for transfer or continuation of eligible benefits to lawful heirs or designated family beneficiaries if the member dies or becomes unable to continue.",heritageText2:"All transfers require identity, legal and compliance verification. The objective is continuity, fairness and protection of the family — with clear records and no hidden deductions.",continuity:"Family Continuity",continuitySmall:"documented • lawful • transparent",
charityEyebrow:"VOLUNTARY CHARITY",charityTitle:"Transparent. Voluntary. Accountable.",charityText:"Charitable participation is never a condition for sporting status, career promotion, Federation membership or access to DOSBALL products.",c1t:"Voluntary",c1:"Members choose whether to contribute, how much and when.",c2t:"Transparent",c2:"Published project goals, incoming funds, outgoing support and periodic reports.",c3t:"Community Benefit",c3:"Support may include athletes’ families, orphans, widows and low-income families through approved charity programs.",
fedEyebrow:"FEDERATION PRINCIPLES",fedTitle:"Clear rules for a global movement.",p1:"Rewards must be calculated and paid transparently, on time and in full according to published rules.",p2:"No sports betting, wagering, gambling, lotteries or gambling-related activity in the DOSBALL ecosystem.",p3:"Referral rewards are connected to real DOSBALL products and services, not to payment for recruitment.",p4:"Career advancement depends on merit, education and real operational responsibility.",p5:"Schools, universities and communities can become development partners subject to local approvals.",p6:"International competitions are planned every two years in new countries to expand awareness of the sport.",
joinEyebrow:"START YOUR DOSBALL PATH",joinTitle:"Player today. Leader tomorrow.",joinText:"This prototype is ready for GitHub Pages and can later be connected to real registration, payments, member accounts, referral tracking and a mobile backend.",createProfile:"Create Demo Profile",studyAcademy:"Explore Academy",footerMission:"Sport • Society • State • Business — together for the benefit of society.",
profileTitle:"Create Demo Member Profile",nameLabel:"Name",ageLabel:"Age",activeLabel:"Monthly video-game purchase is active",saveProfile:"Save Demo Profile"
},
ru:{
navSport:"Спорт",navAcademy:"Академия",navCareer:"Карьера",navEcosystem:"Экосистема",navCharity:"Благотворительность",navFederation:"Федерация",
eyebrow:"НОВЫЙ МИРОВОЙ СПОРТ • ГЛОБАЛЬНАЯ ЭКОСИСТЕМА",heroTitle:"От простого игрока клуба — до международного руководителя.",heroLead:"DOSBALL объединяет спорт, общество, государство и бизнес на благо общества — через клубы, цифровые продукты, образование, прозрачные вознаграждения и добровольную благотворительность.",joinBtn:"Вступить в Федерацию",careerBtn:"Посмотреть карьерный путь",ageRange:"возраст членов",periods:"периода чистого времени",rules:"основных правил",leagues:"профессиональные лиги",heroCard:"Баскетбол + Волейбол + Гандбол + Регби + Футбол — переосмысленные как новый суперспорт.",
sportEyebrow:"СПОРТ",sportTitle:"Быстро. Физично. Зрелищно.",sport1t:"Три периода",sport1:"1-й: кроссовки • 2-й: роликовые коньки • 3-й: кроссовки. Каждый период — 20 минут чистого времени.",sport2t:"Шесть на площадке",sport2:"Одновременно играют 6 спортсменов, замены — как в хоккее, состав команды — до 25 игроков.",sport3t:"Уникальный счёт",sport3:"Удар кулаком через кольцо — 2 очка. Бросок рукой — 1 очко. В игре используются удары коленом.",
academyEyebrow:"АКАДЕМИЯ ПРЕЕМСТВЕННОСТИ",academyTitle:"Чемпионы становятся наставниками, менеджерами и будущими лидерами.",academyText:"Академия преемственности превращает спортивные достижения в образование, профессиональное развитие и долгосрочное лидерство внутри Федерации DOSBALL.",
a1t:"Игрок клуба",a1:"Тренировки, правила, командная работа, цифровой профиль и первые соревнования.",a2t:"Региональный участник",a2:"Участие в местных и региональных чемпионатах.",a3t:"Игрок лиги",a3:"Продвижение в Premier, High и Super National League.",a4t:"Чемпион / 1–3 место",a4:"Призёры входят в Академию преемственности и лидерский трек.",a5t:"Тренер / менеджер клуба",a5:"Подготовка по тренерству, управлению клубом, этике, финансам и социальной работе.",a6t:"Международный региональный директор",a6:"Руководство клубами DOSBALL в регионе или стране на основе результатов и сертификации.",a7t:"Член Совета Федерации",a7:"Лучшие лидеры могут быть выдвинуты в органы управления Федерации согласно её правилам.",
careerEyebrow:"КАРЬЕРНЫЙ РОСТ",careerTitle:"У каждого игрока есть понятный путь вперёд.",careerRuleT:"Главное — заслуги.",careerRule:"Повышение зависит от спортивных результатов, образования, этики, лидерства, подтверждённого опыта и требований Федерации — а не только от привлечения людей.",
ecoEyebrow:"ЭКОСИСТЕМА DOSBALL",ecoTitle:"Одно членство. Спорт, цифровые продукты и предпринимательство.",gameTitle:"Доступ к видеоигре DOSBALL",gameText:"Ежемесячная покупка активирует личный доступ на один месяц и преимущества Экосистемы Федерации, привязанные к активному аккаунту.",refTitle:"Персональная реферальная ссылка",refText:"Любой соответствующий правилам член Федерации в возрасте 10–70 лет может получать персональную реферальную ссылку, пока активна ежемесячная покупка видеоигры.",generateBtn:"Создать демо-ссылку",copyBtn:"Копировать",rightsTitle:"Использовать, подарить или перепродать на 1 месяц",rightsText:"Активное месячное цифровое право можно использовать лично, подарить или предложить к продаже на срок одного месяца — согласно правилам Федерации и применимому законодательству.",minorT:"Для участников младше 18 лет:",minorText:"коммерческие действия, платежи и договоры должны осуществляться с согласием родителя/опекуна и в соответствии с местным законодательством.",
heritageEyebrow:"ПРЕЕМСТВЕННОСТЬ И НАСЛЕДОВАНИЕ",heritageTitle:"Вклад участника может продолжать работать для его семьи.",heritageText:"Если член Федерации создал признанную команду DOSBALL, сеть клубов или квалифицирующийся бонусный аккаунт, правила Федерации могут предусматривать передачу или продолжение допустимых выплат законным наследникам или указанным членам семьи в случае смерти или невозможности продолжать деятельность.",heritageText2:"Любая передача требует подтверждения личности, юридической проверки и соблюдения правил. Цель — преемственность, справедливость и защита семьи с понятным учётом и без скрытых удержаний.",continuity:"Преемственность семьи",continuitySmall:"документально • законно • прозрачно",
charityEyebrow:"ДОБРОВОЛЬНАЯ БЛАГОТВОРИТЕЛЬНОСТЬ",charityTitle:"Прозрачно. Добровольно. Подотчётно.",charityText:"Благотворительность никогда не является условием спортивного статуса, карьерного продвижения, членства в Федерации или доступа к продуктам DOSBALL.",c1t:"Добровольно",c1:"Участники сами решают, помогать ли, сколько и когда.",c2t:"Прозрачно",c2:"Публикуются цели проектов, поступления, направления помощи и регулярные отчёты.",c3t:"Польза обществу",c3:"Помощь может направляться семьям спортсменов, сиротам, вдовам и малообеспеченным семьям через утверждённые благотворительные программы.",
fedEyebrow:"ПРИНЦИПЫ ФЕДЕРАЦИИ",fedTitle:"Понятные правила для глобального движения.",p1:"Вознаграждения должны рассчитываться и выплачиваться прозрачно, вовремя и полностью по опубликованным правилам.",p2:"В Экосистеме DOSBALL запрещены спортивные ставки, пари, азартные игры, лотереи и любая деятельность, связанная с азартными играми.",p3:"Реферальные вознаграждения связаны с реальными продуктами и услугами DOSBALL, а не с оплатой за само привлечение людей.",p4:"Карьерный рост зависит от заслуг, образования и реальной управленческой ответственности.",p5:"Школы, университеты и сообщества могут становиться партнёрами развития при наличии необходимых местных разрешений.",p6:"Международные соревнования планируются раз в два года в новых странах для расширения известности спорта.",
joinEyebrow:"НАЧНИ СВОЙ ПУТЬ В DOSBALL",joinTitle:"Сегодня игрок. Завтра лидер.",joinText:"Этот прототип готов для GitHub Pages. Позже можно подключить настоящую регистрацию, платежи, аккаунты членов, реферальный учёт и мобильный backend.",createProfile:"Создать демо-профиль",studyAcademy:"Изучить Академию",footerMission:"Спорт • Общество • Государство • Бизнес — вместе на благо общества.",
profileTitle:"Создать демо-профиль участника",nameLabel:"Имя",ageLabel:"Возраст",activeLabel:"Ежемесячная покупка видеоигры активна",saveProfile:"Сохранить демо-профиль"
}
};

let lang = localStorage.getItem("dosballLang") || "en";

function renderCareer(){
  const data = lang === "ru" ? careerRu : career;
  document.getElementById("careerTrack").innerHTML = data.map(([n,title,desc]) =>
    `<article class="career-item"><div class="level">LEVEL ${n}</div><h3>${title}</h3><p>${desc}</p></article>`
  ).join("");
}

function applyLanguage(){
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach(el=>{
    const key = el.dataset.i18n;
    if(t[lang][key]) el.textContent = t[lang][key];
  });
  document.querySelectorAll("[data-lang]").forEach(b=>b.classList.toggle("active", b.dataset.lang===lang));
  renderCareer();
}

document.querySelectorAll("[data-lang]").forEach(btn=>btn.addEventListener("click",()=>{
  lang = btn.dataset.lang; localStorage.setItem("dosballLang",lang); applyLanguage();
}));

document.getElementById("menuToggle").addEventListener("click",e=>{
  const nav=document.getElementById("mainNav"); nav.classList.toggle("open");
  e.currentTarget.setAttribute("aria-expanded",nav.classList.contains("open"));
});
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("mainNav").classList.remove("open")));

document.getElementById("generateReferral").addEventListener("click",()=>{
  const rand=Math.random().toString(36).slice(2,8).toUpperCase();
  const link=`https://dosball.example/join?ref=DOS-${rand}`;
  document.getElementById("referralLink").textContent=link;
  document.getElementById("referralBox").classList.remove("hidden");
});
document.getElementById("copyReferral").addEventListener("click",async()=>{
  const text=document.getElementById("referralLink").textContent;
  try{await navigator.clipboard.writeText(text);}catch(e){}
  document.getElementById("copyReferral").textContent=lang==="ru"?"Скопировано":"Copied";
  setTimeout(()=>document.getElementById("copyReferral").textContent=t[lang].copyBtn,1200);
});

const modal=document.getElementById("profileModal");
document.getElementById("openModal").addEventListener("click",()=>modal.showModal());
document.getElementById("saveProfile").addEventListener("click",()=>{
  const name=document.getElementById("memberName").value.trim();
  const age=Number(document.getElementById("memberAge").value);
  const active=document.getElementById("activeGame").checked;
  const box=document.getElementById("profileResult");
  if(!name || age<10 || age>70){
    box.textContent=lang==="ru"?"Укажите имя и возраст от 10 до 70 лет.":"Enter a name and an age from 10 to 70.";
    return;
  }
  const minor=age<18;
  const msg=lang==="ru"
    ? `${name}: демо-профиль создан. Реферальная функция ${active?"активна":"не активна"}${minor?". Для коммерческих действий требуется участие родителя/опекуна.":""}`
    : `${name}: demo profile created. Referral eligibility is ${active?"active":"inactive"}${minor?". Parent/guardian involvement is required for commercial activity.":""}`;
  box.textContent=msg;
});
document.getElementById("year").textContent=new Date().getFullYear();
applyLanguage();
