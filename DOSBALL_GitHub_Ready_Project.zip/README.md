# DOSBALL Super Sport International — GitHub Pages Prototype

This repository contains a responsive front-end prototype for the DOSBALL Super Sport International ecosystem.

## Included

- DOSBALL sport overview
- Academy of Succession
- Full athlete-to-leadership career ladder
- International Regional Director and Federation Council pathway
- Monthly video-game access model
- Personal referral-link demo
- One-month personal / gift / resale entitlement concept
- Family continuity / inheritance concept
- Transparent and voluntary charity principles
- Federation principles
- Explicit prohibition of betting, wagering, gambling and lotteries
- English / Russian language switch
- Mobile-first responsive layout
- Demo member profile
- GitHub Pages compatible, no build process required

## Publish on GitHub Pages

1. Upload `index.html`, `styles.css`, `app.js`, `.gitignore` and this `README.md` to the root of your repository.
2. Commit the files to the `main` branch.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**.
6. Save. GitHub will generate a public Pages URL.

## Important

This is a front-end prototype. Real registration, authentication, payments, referral accounting, resale/gifting, inheritance, charity reporting and Federation governance require a backend, database, payment provider, legal terms and jurisdiction-specific compliance.

For members under 18, any commercial activity must be handled with parent/guardian consent and in compliance with local law.

The demo referral URL uses `dosball.example` intentionally. Replace it with the final DOSBALL domain when the backend is ready.
